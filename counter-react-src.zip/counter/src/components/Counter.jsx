import { useReducer } from 'react';

function reducer(state, action) {
  switch (action.type) {
    case 'increment':
      return { ...state, count: Math.min(state.count + state.step, state.max) };
    case 'decrement':
      return { ...state, count: Math.max(state.count - state.step, state.min) };
    case 'reset':
      return { ...state, count: state.initial };
    default:
      return state;
  }
}

// A counter with a step, a minimum and a maximum.
export default function Counter({ initial = 0, step = 1, min = 0, max = 100 }) {
  const [state, dispatch] = useReducer(reducer, { count: initial, initial, step, min, max });

  const atMin = state.count <= min;
  const atMax = state.count >= max;

  return (
    <section className="counter" aria-label="Counter">
      <output className="value" aria-live="polite">
        {state.count}
      </output>

      <div className="buttons">
        <button onClick={() => dispatch({ type: 'decrement' })} disabled={atMin}>
          −
        </button>
        <button onClick={() => dispatch({ type: 'reset' })}>Reset</button>
        <button onClick={() => dispatch({ type: 'increment' })} disabled={atMax}>
          +
        </button>
      </div>

      {atMax && <p className="note">Maximum of {max} reached.</p>}
      {atMin && state.count !== initial && <p className="note">Minimum of {min} reached.</p>}
    </section>
  );
}
