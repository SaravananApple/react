import Counter from './components/Counter.jsx';

export default function App() {
  return (
    <main className="app">
      <h1>Counter</h1>
      <Counter initial={0} step={1} min={0} max={100} />
    </main>
  );
}
